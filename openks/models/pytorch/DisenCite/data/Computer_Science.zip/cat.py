import json

if __name__ == '__main__':
    papers = []
    for file in ['train_data.json', 'valid_data.json', 'test_data.json']:
        with open(file, 'r', encoding='utf-8') as f:
            for line in f:
                paper = json.loads(line)
                papers.append(paper)

    with open('data.json', 'w', encoding='utf-8') as f:
        for paper in papers:
            data = json.dumps(paper, ensure_ascii=False)
            f.write(data + '\n')
